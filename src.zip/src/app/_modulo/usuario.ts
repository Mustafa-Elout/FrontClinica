export class Usuario{
  username: string;
  password: string;
  enabled:boolean;
}
