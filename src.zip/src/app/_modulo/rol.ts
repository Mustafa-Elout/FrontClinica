export class Rol {
  idRol: number;
  descripcion: string;
  nombre: string;
}
