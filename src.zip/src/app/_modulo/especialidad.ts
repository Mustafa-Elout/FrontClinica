export class Especialidad{
  idEspecialidad: number;
  descripcion: string;
  nombre: string;
}
