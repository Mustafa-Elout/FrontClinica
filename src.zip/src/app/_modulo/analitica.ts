export class Analitica{
  idAnalitica: number;
  descripcion: string;
  nombre: string;
}
