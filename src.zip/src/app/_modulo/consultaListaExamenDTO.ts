import { Analitica } from "./analitica";
import { Consulta } from "./consulta";

export class ConsultaListaExamenDTO {
    consulta: Consulta;
    lstExamen: Analitica[];
}
