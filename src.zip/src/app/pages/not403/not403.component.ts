import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-not403',
  templateUrl: './not403.component.html',
  styleUrls: ['./not403.component.css']
})
export class Not403Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
